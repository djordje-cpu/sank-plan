# Šank

Front-of-house-first restaurant platform for Serbia. Start with `CLAUDE.md`, then `docs/PLAN.md`. Regulatory contract in `docs/certification/`. Prototypes in `design/prototypes/` are reference only.
